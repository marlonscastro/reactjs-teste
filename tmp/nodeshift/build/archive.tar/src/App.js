import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Teste ReactJS no Openshift 3.11. v1</h1>
    </div>
  );
}

export default App;
